#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

// ---------- Pinos ----------
#define DHT22_PIN 23
#define LDR_PIN   34
#define LED_OK    26
#define LED_ALERT 27
#define BUZZER    25

// ---------- Limites de alerta (ajuste conforme a cultura) ----------
const float TEMP_MIN = 18.0, TEMP_MAX = 30.0;
const float HUMI_MIN = 40.0, HUMI_MAX = 80.0;
const int   LUZ_MIN  = 20;   // % mínimo de luz

// ---------- WiFi e nuvem ----------
const char* WIFI_SSID = "Wokwi-GUEST";   // rede virtual do Wokwi (sem senha)
const char* WIFI_PASS = "";
const char* API_KEY   = "SUA_WRITE_API_KEY";  // chave do ThingSpeak

LiquidCrystal_I2C lcd(0x27, 16, 2);
DHT dht22(DHT22_PIN, DHT22);

unsigned long ultimoEnvio = 0;
const unsigned long INTERVALO_ENVIO = 20000;  // ThingSpeak grátis: mín. 15 s

void beep() {
  for (int i = 0; i < 200; i++) {   // ~0,2 s de tom em 1 kHz
    digitalWrite(BUZZER, HIGH); delayMicroseconds(500);
    digitalWrite(BUZZER, LOW);  delayMicroseconds(500);
  }
}

void enviarNuvem(float t, float h, int luz) {
  if (WiFi.status() != WL_CONNECTED) return;
  HTTPClient http;
  String url = String("http://api.thingspeak.com/update?api_key=") + API_KEY +
               "&field1=" + t + "&field2=" + h + "&field3=" + luz;
  http.begin(url);
  int codigo = http.GET();
  Serial.printf("Envio ThingSpeak: HTTP %d\n", codigo);
  http.end();
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_OK, OUTPUT);
  pinMode(LED_ALERT, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  dht22.begin();
  lcd.init();
  lcd.backlight();

  lcd.print("Conectando WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASS, 6);   // canal 6 = padrão do Wokwi
  while (WiFi.status() != WL_CONNECTED) delay(300);
  lcd.clear();
}

void loop() {
  float h = dht22.readHumidity();
  float t = dht22.readTemperature();
  int luz = map(analogRead(LDR_PIN), 0, 4095, 0, 100);  // verifique o sentido na simulação

  lcd.clear();
  if (isnan(t) || isnan(h)) {
    lcd.print("Falha no sensor");
    digitalWrite(LED_ALERT, HIGH);
    delay(2000);
    return;
  }

  bool alerta = (t < TEMP_MIN || t > TEMP_MAX ||
                 h < HUMI_MIN || h > HUMI_MAX ||
                 luz < LUZ_MIN);

  digitalWrite(LED_OK,    !alerta);
  digitalWrite(LED_ALERT,  alerta);
  if (alerta) beep();

  lcd.setCursor(0, 0);
  lcd.printf("T:%.1fC H:%.0f%%", t, h);
  lcd.setCursor(0, 1);
  lcd.printf("Luz:%d%% %s", luz, alerta ? "ALERTA" : "OK");

  if (millis() - ultimoEnvio >= INTERVALO_ENVIO) {
    enviarNuvem(t, h, luz);
    ultimoEnvio = millis();
  }

  delay(2000);
}